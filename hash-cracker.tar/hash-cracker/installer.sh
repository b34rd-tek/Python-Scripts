#!/bin/bash

tar xvf passlib-1.6.1.tar.gz &&
tar xvf pyDes-2.0.1.tar.gz &&

cd passlib-1.6.1 &&
python setup.py install &&
cd .. &&
cd pyDes-2.0.1 &&
python setup.py install &&
cd .. &&
rm -rf pyDes-2.0.1* &&
rm -rf passlib-1.6.1*

