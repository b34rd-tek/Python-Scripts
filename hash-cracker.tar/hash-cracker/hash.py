#!/usr/bin/python

from Tkinter import *
import tkMessageBox, sys, os, pyDes, base64, getopt
from tkFileDialog import askopenfilename
from subprocess import call
from passlib.hash import atlassian_pbkdf2_sha1 as e

# ===============================================
# Setup Classes
# ===============================================

class App:

    def __init__(self, master):
        
# =======================
# Setup Actions
# =======================

        def submit ():
            selection = hashType.get()
            pword = passwordList.get()
            hash = passwordHash.get()
            if ( selection == "Atlassian" ):
                    atlassian(pword, hash)                    
            elif ( selection == "ColdFusion" ):
                coldfusion(hash)
            else:
                tkMessageBox.showerror(
                "Selection Error",
                "You failed to make a selection!")
            return

        def quit ():
            root.destroy()
            exit(0)

        def atlassian (p,h):
            if p == "":
                tkMessageBox.showerror("Error", "You must supply a " +
                "password list")
            else:
                if h == "":
                    tkMessageBox.showerror("Error", "You must supply a " +
                    "password hash.")
                else:
                    if (len(h) != 73) and (h[0:9] != "{PKCS5S2}"):
                        tkMessageBox.showerror("Error", "Hash is not a " +
                        "valid Atlassian hash.")
                    else:
                        processList = StringVar()
                        top = Toplevel(root)
                        Label(top, text="Please wait while I process" +
                        " the hash...").pack()
                        Label(top, text="").pack()
                        Label(top, textvariable=processList).pack()
                        with open(p) as passwords:
                            for line in passwords:
                                password = line.rstrip('\n')
                                processList.set(password)
                                top.update()
                                test = e.verify(password, h)
                                if (test == True):
                                    processList.set("Password Found!" +
                                    "\nPassword: " + password)

        def coldfusion (p):
            if p == "":
                tkMessageBox.showerror("Error", "You must specify a hash!")
            else:
                if (len(p) != 24):
                    tkMessageBox.showerror("Error", "Hash must be 24" +
                    " characters.")
                else:
                    if (p[22:24] != "=="):
                        tkMessageBox.showerror("Error", "Hash is not a " +
                        "valid Cold Fusion hash.")
                    else:
                        pwd = p
                        seed = "0yJ!@1$r8p0L@r1$6yJ!@1rj"
                        key = pyDes.triple_des(seed)
                        decrypted_key = key.decrypt(
                        base64.decodestring(pwd), "*")
                        tkMessageBox.showinfo("Cold Fusion Decrypted",
                        "Decrypted Password: \n" + decrypted_key)

# ======================
# Setup Interface
# ======================

        master.title("Hash Decryptor")
        frame = Frame(master)
        photo = """R0lGODlhTwBkAPf/AAABAAwKBgwLCRENCBwVDBYSDRcXFiQbEyIfHisiGTcpGiooJzw2Mz45Nj85
OTYuKR8gH0k5KVg8LEM8O0g9OUcxHUtAPkdAPFtHPnNLLGdKNHdXOHNPL3d1MnJvHw8MWjo1Rjoz
Vi8qVAkIeQ0Laiolazs1aykpeTYxcSAbekE6R2Y0WUQ1b0ZCQkxEQ01MS0xHR1FGQ1NJRlRMSllN
SldKRlpRTVVQTUtHVlNNVk9QXFxTUlBQXFtWVmFXVmRcW2RbWm9WSWNhX2lgX31xTEpIYVdWY0dB
d1VOcmReYWhPdWFhYGtkY2pqaWllaXNranRxc3p0dHJzeHVybF9gX5pVHY9LH4tLI5hZKIVYNpRd
NoxSKaBeKJhiNpVhNKxsLKZlKrRyLbl2L6JlM6psMqluO6RqOKxyPa1xNrR0NLJ1O7Z5O7t7O7l4
NLBuL41YTYRjRZdmQ5NvV610Qqh3TbF2QrZ6Q7p9Q7V8Sbl8TLB3S6l6Vqp1UYF8fJJrarN8ZpeW
E7OzFZaUMayrObm2N8WFPsC9I9LRDerqBvHxAf//AfTzCuXkFMTDJsvJK5mUTL6BQ7uDTbmFWK2F
XJKCc6uHaraMcsODRMKFSsuMTMeJSMWKU86RVtOUVdiaWs+QTcyTZdSaZceaecONaduhadqnd82i
feOnbOStdgQChwoKiBILiBcXhQsElxIHlhsWmQ0QmSQclS0ekCkkhz02lTktjwEBrQkFqBQKqBwU
pQQAsgkBsg0CuwoJuxYKuRgUuCYYuCgdrSslqDUrpygiuDgmvDkxrkg4nU0zkko2uT9Bik9KlX1a
m3JSjVxXukxEsmxns2VdowIDxAsCxAIDyQ0AzQoKxRQKxRsLxRABzRUGxRwSxAwA0BgK0CESwS4i
0zwuzEI+xpRwiaJ6jYmFhJSMipqTkqKdnLuShLqllbazscypitith963l+e3iei8leSvgMGunu/D
nN3CqfHOrdPRz+zaye7czPTl2vTgyfz16/Ly+v7//fr59ezp6////yH5BAEKAP8ALAAAAABPAGQA
AAj+AD+kGkiwoMGDCBMqXMiwYapqECFmq5atIkWKEzFqrMgto8WJFUFKFCmxI0aSID9qvPgxWyqL
1aZRm0nt4kWaM0NGxLmyGs6aKn+q9ElzJESeJF/eFJqN21GcMIkWTfmzplGhEbP93Ch1JkuXGbsC
FblVolibT3lGPLu2rMSqNl22dZvWazVrda3upJt3rVi9fY+6VLtXbUa+fO8iJjyxalS7g4tmdRyW
rlasFLnB1bg15OWpHRsDrZZK2lSMjm1upeaUmzXCZmeattaUm2u3jU3PxGvSJ8vSUy1SXlp0mzBs
n72G/VtNGDDb1HSPLax8uUXgyufSbEo8Oq4jPWr++TQtzbRRqaaFGeExy1d0mngPC7W91iT20RVT
C5/Z64QKGTYIcQxO0pxE0U/C6NDDDS2E0Et5dq2lmzS0wdTSfVkll51TMwlzwgUv3PADED8s89pu
HYWG0y9N9DCEDS+4AEIKJ3qmmWyA+VYShhHdBpVO1szSQgMXtNBDEknskMQv71kFE03I3ODiEDi0
YKUJxbBGEo7UVJZSNqpE99pXXHbpVDW/oBCjCzBI+YMPbS7zy2w2cWjNMj+80MOIO1gJog6zbPMk
bNVRlApSHJVZjWu5gHCBCy+0oKcMPfiw5xDLPEhfSDMRw8QPO9DQgw03MCiplSz8ol2Eo13EI3X+
M3GzDQsgODABDC/AUIMMMdRg6QwwwPBKhAdaY0IMMeSwgw3AxjADsCpQ4EAIr+RllWQRpYJXYEdV
s4sJFzCgwgXBzoDBfzb4QAMNJoSAwzUn4hQLAybgYMMON8gAgwsz0DCDCxc44AAIueSoY1oQPbQf
thQFI0IDDhDpggwy0FDDuqEicYw2wNAyjFhpxpINMUjQkEMONOibsgUWBDwBCLFcw1FjqhX1kEmb
aVMLCBNMcAEFF8jwgg00qLAuDBGwwF01wFTlC3IdySIBv/5OYLEMLUwQcQMqmOCLiq1O9RJIcGlT
wgQM2EoBBRZQvG4NO9QQAQdxIIPRjUWdmU3+MXFkIUEEz85gw8Ux9MwAAxM8IIIvccmX00tnbnUN
CkBfMAEFl8dAMYA++FBDFmaYwYc3o6nlFTNdlKGFBjRYOngNNUR7+OUUhDCMNudJNsIuvO9iy++6
2LILCjLM8MIFDVyuQgwT+xpqBmaMMQYdzeiii++/2xL89rz40QUXYGyBAQ0v1sA8yz1PILjJuFz/
O/bZ77KADvTXX38OM+zQAxA79IysCy6wANxooAEtlEENYziDFlpgvwbqAAdyqAMZxpCGLmRhgBYA
YAwsgLkZJOFNOWCgA+2HA36Y8IQnrMcThMCEIfRgBy7oFbI4SINy/AEPamgDGKY3DxT6kB/++LAE
GtCQhjVcwhLpiALL3GY+GgAhCU0QghDO8UMfvqCKJ1SHFKLQhCHwr2I0gAGyzqEPfLBjE2xIwxfI
MIl7YLEf69ADGsKQhjuEwh78qAcQNAege/0gCUyYQhTI4Q8snvCKhuyHOszRhykwgQnqulo5TogP
d3CiDWEAwxnYgUV7ROILXwgDJDwhj36YUB1A2FXFhuAEJ0SBEucopCFNCIEm2PKWTZDCLanQh3JE
IQqQpMEOduCDH9gSCj9IhzsuAco0SCIduLTlOURxhlCmIRSjCIIum/CEN3mOBkxwwhTIYQ5mQCGa
6GwCANbJznaykwHmIEcUnpAEdflgAe7+PIAoSCEGNdahC+4EAAciEYZQRoIdMnCnAYRZzCcM8hxR
EEBAJ0rRgL5AHL50AiRrYICA1mAengiDG9KQhywUgJ0aiEQ1vwAJeViio+5cABB8wIQo9IEcT4Bp
RXdKUQPY1Ak/iIFO2ykAP8wjE2GgYx40sM4C6EENoWzDO9BxgIkWQAXFHCc+ecrVno6qB1ud6AAm
8Y5L0JEMcThAATZghzSIQQyksERVe3qBYg61q3htpwFaMICdDsASpVhDG9IAiTjAoa395IQ8HsDT
BLQgrHmNbGQj4A5StCGNeZDEGQabCXlQ4qSSDa1oKxqAIMhjE2pYQx7aSkRSyKGvo43+rWxRWopN
4OEOa0ADJEgxCdjO9reiDYAcQGEHwRYCFfK4AHCXG9q1YmINbNAEKughCuUy97pdHWhxC3EKengC
E3WYK3bHG9AKlOEOd7hEZ90BiTtAggPkjS87LxAJSGTiE5pwBz1IoQlNQEITHJCofLE7gD3YARII
RsU6KCGPTyB4DZKIwICvO4ANRMIOmvDEKUqhgALIQR6dcLAd6JAAAU9YtgHgAB7WUAhPoKIUjAVA
ASqBCk9owg5n2IN1TxzbDeBhDmy4hCc8IWF2EmASp/BEIdQwBy+AlsehTQAfiivkU+yYnQlAsibW
cIY1eIEAUJasAbwwhzqsgRPuiEP+ACaaAFSEohBrqAMkNhDmvBKAzHLOBComcVd2CoAIp+gEJOxg
hzgooM5cFQAc6nBAIdPBtxTdQCg+cQkm00G8s4XAEoSwBCpQgdNLCLWoR03qJfwgCHc4wxns4OIp
GEHUn6bCqKXIjlNgQg1qOEMWdlDqUX8a1L0WgqwROcti32MTjFZDJrpb7BPqw82QSMMZ6tCOZlub
2Nb+IRxVfYZLMDvb/MgHKjixBjKUIQ/2MCW4q4jtdZtwHowmgxrQrG5w5+MUbHDDHOawDn2424f9
eME+Bk7wghv84PfYw/fScIk7HvzhBvcHOzrBBunNgR0Qz/jBl/GNjnv84yAHOTj+/DCHLoDhEp0Q
R8hXvvJkWAITbhjDHN6QDJbb/OPCgIZfds5z2xyjDFjgwhc+gQ5v2OZMMeG5X7KhDXGMQg1c4MIY
fMALpStdLyT4x056YpimAOMNY8ACGVjNjNMshShcWVQySnEJN0RdC8jgEGRwVpSZTKMaJdB6t2Lj
lq9rIehk2IQlsCEVnVSlS0vhRjeYAQo2cAELWniDLBC1sKdQBBp6h8xOpBMRJWhhC1yoQhpA0Qyp
ZAguoUF7NbZhiU2Engta0IIw8rawa1nlH/+4BbbyU5ZiyOEKW6gCF/Igim0whSIymY9WfFORcYAC
DFywAvCb8SPi7L0auJ/F7jX+xBqKIOMKVqiCG0IRd6RE7ie02XlNgAEK10s/CNeQDFkQryNe4D4c
VhmTb3ZTk9GwIPx5YApxpxn7h3bWoAtFcALTQICqBxHY4HRkUAUrUAz7Rw1jUnf9BxGrgHv/cH7b
x3wVgQxy8AfiQAxIRxS9QAys0AGNQAiIAAjYUHcHww3D8Ad8sAKMcxJNkhOd4Qu41wrTIBrBwXta
kg3dcA3YEIN+sQw8AAiMsAiLoAhSyAhN03+aVxHdgA3a4BTLsRpIwYH/QAxEaHamlxmXYRbVgASJ
IIVsOIW5UIBWVyhCuBnVwAuqwIHdcCA4kX6OsyhCmBV12AFtyIaJ8ALX1xb+qsESf/Eea0EMYHgL
czgWjmOBZTER1sANwuAIgyiFhIB2JwgYV1gVEGIW3QCG/4A7wyGEeFGJsWIsh7CJnciDesEqelF7
aLd82rCBYBiEqDeHT6Ebe4F8j7CJjbAKrHEjFYgwLMETGFgRpvgPH1OJwZgbwJgWFeELgzCIiWAE
rCEZGcgYlkczRJENu/CMznAWvdGAO4gwHMEKgcCGgOAEwiB32+KN1SF3+Wd72dAKz5h7O9glT6Id
5iEUvCAMtQAIbHgIvBA5A+kT8VIdRLgowWh//WiJOuIVF4h2VqiRENEK79iGiVAE3XItyfiNilGP
e8EN/NiPH7CQZMOMXff+JWh3A2vYhoPQfYbXLYZnOoyBDf2Ie8DgGYfHE6nXhTXhC4QwiIcwC0hn
F9nRF8xoEcDwkxyIO3o4lAB5IGjRLcLQCIMoCF/zGXq4EliZFdwwDVTJgcPAKTC5HcKxFpXRHF5J
iLUgd9PYHXtoFtlAkWn5D7zQFG0pf5BRGVYhAjUphR7QC6AYihgIGBPRlxzoComSE+hBf8RSGNVw
DcOoCC84BfpnhbXYFZYHGZDJgb6QG4gnG+ZRhtpRDdrwCyaACIoQCGFCLMFxlatIkjFRmhxIG9gi
HbaXI/DBDa4QCLKpCIdgArMomoRpe1KhDbjAm5GZHQTSJYQBmkfRDFH+KIVEUCCrYiDUmRzZIJ1g
+JReSIuX6QQ1GQix0BGHFxeXSRNoSZ4cSAzb8hQnIpp755TVcAuCwIbLgIyrEYyISA26SJ+4BwtE
GRqP4RXOGSu0oImKcARDCJUOGhHziaC96ZYW4oEOKhlOgQNrKAiK2SqRqHkQsQ0a+ozbcRNXwRyU
WQ298J+M4A23WBEPyTDZ4AvRsKLPaB6icR7c95RMQwiMkAItOok7d5ZZ56OmuAy6cH4psRfJV3hr
AQyEIAgtipeIuJJOaoqswDhmB5oa8hZWYQQ3GSs7yTC80AtfSpV4w3fKQYnVWBTXgAxhohH4GCG6
0KRv+pNb2hn6WYaQuqB7iFd7/ZcNefenaXkLvYCf6OmUbokUsFITjFqazhCkkQoXoEl/dSENI3Cp
0jkslkcd+okYMXELokqfudAKnfoVOgiIfcELqrqqCDoCvnAi3rkcO6ETQkghtmCrTuoM0mCo6SiO
TnIZtiANrCCsjGoN4VAtDkkzdkcRuDAM1OCs2goNHyAQA9GtPaqt/xAQADs="""
        photo = PhotoImage(data=photo)  
        frame.pack()

# =========================
# Setup Radio Buttons
# =========================

        Label(frame, text="Select hash type:").grid(row=0, column=1)
        hashType = StringVar()
        hashType.set(None)
        Radiobutton(frame, text = "Atlassian", value = "Atlassian",
        variable = hashType).grid(row=1, column=1, sticky='w')
        Radiobutton(frame, text = "Cold Fusion", value = "ColdFusion",
        variable = hashType).grid(row=2, column=1, sticky='w')
        Label(frame, text = "( Bamboo, Jira, Confluence, etc )").grid(row=1,
        column=2, sticky='w')
        Label(frame, text = "( Adobe Cold Fusion Data Source )").grid(row=2,
        column=2, sticky='w')

# =========================
# Labels for Entries
# =========================

        Label(frame, text = "Password Hash:").grid(row=3, column=1,
        sticky='w')
        Label(frame, text = "Password List:").grid(row=4, column=1,
        sticky='w')

# ==========================
# Setup Text Entry Fields
# ==========================

        passwordList = StringVar(None)
        passwordHash = StringVar(None)
        def openfile():
            name = askopenfilename()
            passwordList.set(name)
        Entry(frame, textvariable=passwordHash).grid(row=3, column=2,
        sticky='w')
        Entry(frame, textvariable=passwordList).grid(row=4, column=2,
        sticky='w')
        Button(frame, text="Browse", 
        command=openfile).grid(row=4,column=2, sticky='e')

# ==============================
# Setup Ok/Quit Buttons
# ==============================

        Button(frame, text = "Ok", command = submit).grid(row=5, column=3,
        sticky='e')
        Button(frame, text = "Quit", command = quit).grid(row=5, column=4,
        sticky='w')

# ===========================
# TS13 Image
# ===========================
      
        photoLabel = Label(frame, image=photo)
        photoLabel.photo = photo
        photoLabel.place(x=335, y=3)


def atlassian(p,h):
    call("clear")
    if (len(h) != 73) and (h[0:9] != "{PKCS5S2}"):
        print("Hash is not a valid Atlassian hash.")
    else:
        print "Atlassian Password Finder ... "
        print " "
        with open(p) as list:
            for line in list:
                pword = line.rstrip('\n')
                os.write(1,"\rChecking: " + pword +
                "                                         ")
                test = e.verify(pword, h)
                if (test == True):
                    print("\nPassword Found!")
                    print(" ")
                    print("Password: " + pword)
                    sys.exit()

def coldfusion(p):
    call("clear")
    if (len(p) != 24) and (p[22:24] != "=="):
        print("Hash is not a valid Cold Fusion hash.")
        sys.exit()
    else:
        print("Coldfusion DataSource Password Decryptor")
        print (" ")
        pwd = p
        seed = "0yJ!@1$r8p0L@r1$6yJ!@1rj"
        key = pyDes.triple_des(seed)
        decrypted_key = key.decrypt(
        base64.decodestring(pwd), "*")
        print("Decrypted Password: " + decrypted_key)
        sys.exit()

def args(args):
    hsh = ""
    lst = ""
    if len(sys.argv) < 3:
        usage()
    try:
        options, remainder = getopt.getopt(args, "a:c:l:h", ['atlassian','coldfusion','hash=','list='])
    
    except getopt.GetoptError:
        usage()
        sys.exit()

    for opt, arg in options:
        if opt == '--help':
            usage()
        elif opt in ('-l', '--list'):
            lst = arg
        elif opt in ('-h', '--hash'):
            hsh = arg
        elif opt in ('-c', '--coldfusion'):
            coldfusion(hsh)
        elif opt in ('-a', '--atlassian'):
            atlassian(lst, hsh)

def usage():
    print "\nHash Cracker 1.0"
    print "Usage: hash.py options\n"
    print "hash.py --list=<password_list> --hash=<hash> --atlassian"
    print " "
    print "--help                    Usage"
    print "--atlassian               Atlassian Password Hash"
    print "--coldfusion              Cold Fusion Password Hash"
    print "--list                    Path to password list"
    print "--hash                    Hash"
    print " "
    sys.exit()

if __name__ == '__main__':
    if len(sys.argv) > 1:
        args(sys.argv[1:])
    else:
        root = Tk()
        app = App(root)
        root.mainloop()
